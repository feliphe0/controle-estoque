import React, { useEffect, useState } from 'react'
import { db, storage, auth } from './firebase'
import ProductList from './components/ProductList'
import ProductForm from './components/ProductForm'
import MovementForm from './components/MovementForm'
import OrdersPanel from './components/OrdersPanel'
import { collection as coll, addDoc, onSnapshot, query, orderBy } from 'firebase/firestore'
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth'

export default function App(){
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [orders, setOrders] = useState([])
  const [user, setUser] = useState(null)

  useEffect(()=>{
    // Simple auth observer
    const unsubscribeAuth = auth.onAuthStateChanged(u=> setUser(u) )
    const q = query(coll(db, 'products'), orderBy('name'))
    const unsub = onSnapshot(q, snap=> setProducts(snap.docs.map(d=>({ id:d.id, ...d.data() }))))
    const q2 = query(coll(db, 'works'), orderBy('name'))
    const unsub2 = onSnapshot(q2, snap=> setCategories(snap.docs.map(d=>({id:d.id, ...d.data()}))))
    const q3 = query(coll(db,'orders'), orderBy('createdAt'))
    const unsub3 = onSnapshot(q3, snap=> setOrders(snap.docs.map(d=>({id:d.id, ...d.data()}))))
    return ()=>{ unsub(); unsub2(); unsub3(); unsubscribeAuth(); }
  },[])

  async function handleCreateProduct(data, file){
    let imageUrl = ''
    if(file){
      const storageRef = ref(storage, `products/${Date.now()}_${file.name}`)
      await uploadBytes(storageRef, file)
      imageUrl = await getDownloadURL(storageRef)
    }
    await addDoc(coll(db,'products'), { ...data, image: imageUrl, quantity: Number(data.quantity) || 0, reserved: 0 })
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="mb-6">
          <h1 className="text-2xl font-bold">Controle de Estoque - Almoxarifado</h1>
          <p className="text-sm text-gray-600">App PWA simples com React + Firebase</p>
        </header>

        <main className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <section className="col-span-1 md:col-span-1 bg-white p-4 rounded shadow">
            <h2 className="font-semibold mb-2">Novo Produto</h2>
            <ProductForm categories={categories} onCreate={handleCreateProduct} />
            <hr className="my-3" />
            <h2 className="font-semibold mb-2">Registrar Movimentação</h2>
            <MovementForm products={products} onCreate={()=>{}} />
          </section>

          <section className="col-span-2 bg-white p-4 rounded shadow">
            <h2 className="font-semibold mb-3">Produtos</h2>
            <ProductList products={products} />
            <hr className="my-4" />
            <OrdersPanel orders={orders} products={products} />
          </section>
        </main>
      </div>
    </div>
  )
}
